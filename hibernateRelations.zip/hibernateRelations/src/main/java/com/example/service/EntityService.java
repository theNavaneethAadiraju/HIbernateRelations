package com.example.service;

import com.example.config.HibernateUtil;
import com.example.entity.*;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EntityService {

    public void savePersonWithAddress() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();

            Person person = new Person();
            person.setName("John Doe");

            Address address = new Address();
            address.setStreet("123 Main St");
            address.setCity("Hometown");
            address.setPerson(person);

            person.setAddress(address);

            session.save(person);
            session.save(address);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void saveDepartmentWithEmployees() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();

            Department department = new Department();
            department.setName("HR");

            Employee emp1 = new Employee();
            emp1.setName("Alice");
            emp1.setDepartment(department);

            Employee emp2 = new Employee();
            emp2.setName("Bob");
            emp2.setDepartment(department);

            department.getEmployees().add(emp1);
            department.getEmployees().add(emp2);

            session.save(department);
            session.save(emp1);
            session.save(emp2);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void saveProductWithOrders() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();

            Product product = new Product();
            product.setName("Laptop");

            Order order1 = new Order();
            order1.setOrderDate(java.time.LocalDate.now());
            order1.setProduct(product);

            Order order2 = new Order();
            order2.setOrderDate(java.time.LocalDate.now());
            order2.setProduct(product);

            product.getOrders().add(order1);
            product.getOrders().add(order2);

            session.save(product);
            session.save(order1);
            session.save(order2);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void saveStudentWithCourses() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();

            Student student = new Student();
            student.setName("Charlie");

            Course course1 = new Course();
            course1.setTitle("Mathematics");

            Course course2 = new Course();
            course2.setTitle("Physics");

            student.getCourses().add(course1);
            student.getCourses().add(course2);

            course1.getStudents().add(student);
            course2.getStudents().add(student);

            session.save(student);
            session.save(course1);
            session.save(course2);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    
    public void testLazyAndEagerLoading() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
          
            Person person = session.get(Person.class, 1L);
            System.out.println(person.getAddress().getStreet()); 

            
            Department department = session.get(Department.class, 1L);
            System.out.println(department.getEmployees().size());
        } finally {
            session.close();
        }
    }

}
