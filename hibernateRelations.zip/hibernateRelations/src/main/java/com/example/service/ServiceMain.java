package com.example.service;

import com.example.config.HibernateUtil;

public class ServiceMain {
    public static void main(String[] args) {
        EntityService service = new EntityService();

        // Save Person and Address
        service.savePersonWithAddress();

        // Save Department with Employees
        service.saveDepartmentWithEmployees();

        // Save Product with Orders
        service.saveProductWithOrders();

        // Save Student with Courses
        service.saveStudentWithCourses();
        
      //  service.testLazyAndEagerLoading();

        // Shutdown Hibernate
        HibernateUtil.shutdown();
    }
}
